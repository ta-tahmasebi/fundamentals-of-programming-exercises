import sys
import os

def copy(a, b):
    os.system(f"cp {a} {b}")

def compile():
    os.system(f"gcc -o bin main.c")

def remove_files(files, i):
    for file in files:
        os.system(f"rm ./test{i}/{file}")


def run(i):
    copy("bin", f"./test{i}/bin")
    before = get_all_txt_files(f"./test{i}")
    os.system(f"cd ./test{i} && ./bin < test.txt && cd ..")
    after = get_all_txt_files(f"./test{i}")
    new_files = list(set(after) - set(before))
    answer = get_all_txt_files(f"./test{i}/output")
    if set(new_files) != set(answer):
        print(f"Test {i} Failed")
        remove_files(["bin"], i)
        remove_files(new_files, i)
        return False
    for file in new_files:
        if not is_same(f"./test{i}/{file}", f"./test{i}/output/{file}"):
            print(f"Test {i} Failed")
            remove_files(["bin"], i)
            remove_files(new_files, i)
            return False
    remove_files(["bin"], i)
    remove_files(new_files, i)
    print(f"Test {i} Passed")
    return True


def is_same(filename1, filename2):
    # using diff
    os.system(f"diff {filename1} {filename2} > .diff.txt")
    with open(".diff.txt") as file:
        lines = file.readlines()
        if len(lines) > 0:
            os.system("rm .diff.txt")
            return False
    os.system("rm .diff.txt")
    return True
        

def get_all_txt_files(path):
    files = os.listdir(path)
    txt_files = []
    for file in files:
        if file.endswith(".txt") and file != "test.txt":
            txt_files.append(file)
    return txt_files

if __name__ == "__main__":
    try:
        compile()
    except:
        print("Compile Error")
        sys.exit(0)
    
    score = 4
    for i in range(4):
        if not run(i):
            score -= 1
    
    os.system("rm bin")
    print(f"You got {score} out of 4")


    
