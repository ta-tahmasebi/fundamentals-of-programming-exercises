import sys
import os

def copy(a, b):
    os.system("cp " + a + " " + b)

def compile():
    os.system("gcc -o output main.c")

def clean():
    os.system("rm -f output result.txt diff.txt input1.txt input2.txt lines.txt output.txt")

def run(i):
    copy(f"test{i}/input1.txt", "input1.txt")
    copy(f"test{i}/input2.txt", "input2.txt")
    copy(f"test{i}/lines.txt", "lines.txt")
    copy(f"test{i}/output.txt", "output.txt")

    os.system("./output < lines.txt > result.txt")
    os.system("diff -b result.txt output.txt > diff.txt")
    if os.stat("diff.txt").st_size == 0:
        print(f"Test {i}: Passed!")
        return True
    else:
        print(f"Test {i}: Failed!")
        return False
    


if __name__ == "__main__":

    score = 5
    tests = 5

    try:
        compile()
    except:
        print("Compilation Error!")
        sys.exit(0)

    for i in range(5):
        if not run(i):
            score -= 1
    print(f"Score: {score}/{tests}")
    clean()
