import os
import sys

def compile():
    os.system("gcc -o output main.c")

def copy(a, b):
    os.system(f"cp {a} {b}")

def run(i):
    copy(f"inputs/input{i}.txt", "input.txt")
    copy(f"outputs/output{i}.txt", "output.txt")
    os.system("./output < input.txt > result.txt")
    os.system(f"diff -b result.txt output.txt > diff.txt")
    if os.stat("diff.txt").st_size == 0:
        print(f"Test {i}: Passed!")
        return 1
    else:
        print(f"Test {i}: Failed!")
        return 0

def clean():
    os.system("rm output diff.txt result.txt input.txt output.txt")

if __name__ == "__main__":

    try:
        compile()
    except:
        print("Compilation Error")
        sys.exit(0)
    
    score = 0
    for i in range(5):
        score += run(i)
    
    print(f"Score: {score}/5")
    clean()

