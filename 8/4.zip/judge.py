import os
import sys
import time

def compile():
    os.system('gcc -o output main.c')

def copy(input, output):
    os.system('cp ' + input + ' ' + output)

def clean():
    os.system('rm output')
    os.system('rm input.dat')
    os.system('rm output.txt')
    os.system('rm result.txt')
    os.system('rm diff.txt')

if __name__ == '__main__':
    # Compile:
    try:
        compile()
    except:
        print('Compile Error!')
        sys.exit(1)
    
    i_tests = 3
    j_tests = 3
    r_tests = 3
    all_tests = 5

    score = i_tests + j_tests + r_tests + all_tests

    # Run I test
    print("Running I tests...\n|")
    check = True
    for i in range(i_tests):
        print(f"|--- I test {str(i)}: ", end = '')
        copy(f'i_format/testcase{i}.dat', 'input.dat')
        copy(f'i_format/testcase{i}.txt', 'output.txt')
        os.system('./output input.dat > result.txt')
        os.system('diff -b result.txt output.txt > diff.txt')
        if os.stat('diff.txt').st_size == 0:
            print(f'passed!')
        else:
            score -= 1
            check = False
            print(f'failed!')
    if check:
        print("|\n|-All I tests passed!\n\n")
    else:
        print("|\n|-Some I tests failed!\n\n")
    
    # Run J test
    print("Running J tests...\n|")
    check = True
    for i in range(j_tests):
        print(f"|--- J test {str(i)}: ", end = '')
        copy(f'j_format/testcase{i}.dat', 'input.dat')
        copy(f'j_format/testcase{i}.txt', 'output.txt')
        os.system('./output input.dat > result.txt')
        os.system('diff -b result.txt output.txt > diff.txt')
        if os.stat('diff.txt').st_size == 0:
            print(f'passed!')
        else:
            score -= 1
            print(f'failed!')
            check = False
    if check:
        print("|\n|-All J tests passed!\n\n")
    else:
        print("|\n|-Some J tests failed!\n\n")

    # Run R test
    print("Running R tests...\n|")
    check = True
    for i in range(r_tests):
        print(f"|--- R test {str(i)}: ", end = '')
        copy(f'r_format/testcase{i}.dat', 'input.dat')
        copy(f'r_format/testcase{i}.txt', 'output.txt')
        os.system('./output input.dat > result.txt')
        os.system('diff -b result.txt output.txt > diff.txt')
        if os.stat('diff.txt').st_size == 0:
            print(f'passed!')
        else:
            score -= 1
            print(f'failed!')
            check = False
    if check:
        print("|\n|-All R tests passed!\n\n")
    else:
        print("|\n|-Some R tests failed!\n\n")

    # Run all tests
    print('Running mixed instruction tests...')
    check = True
    for i in range(all_tests):
        print(f"|--- Mixed Instructions test {str(i)}: ", end = '')
        copy(f'all_formats/testcase{i}.dat', 'input.dat')
        copy(f'all_formats/testcase{i}.txt', 'output.txt')
        os.system('./output input.dat > result.txt')
        os.system('diff -b result.txt output.txt > diff.txt')
        if os.stat('diff.txt').st_size == 0:
            print(f'passed!')
        else:
            score -= 1
            print(f'failed!')
            check = False
    if check:
        print("|\n|-All mixed instruction tests passed!\n\n")
    else:
        print("|\n|-Some mixed instruction tests failed!\n\n")
    
    clean()
    
    print(f"Your score: {score}/{i_tests + j_tests + r_tests + all_tests}")
